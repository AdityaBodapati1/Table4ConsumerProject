class ReviewRunner {
  public static void main(String[] args) 
  {
    /* your code here, for example: */
    System.out.println(Review.sentimentVal("good"));
  }
}